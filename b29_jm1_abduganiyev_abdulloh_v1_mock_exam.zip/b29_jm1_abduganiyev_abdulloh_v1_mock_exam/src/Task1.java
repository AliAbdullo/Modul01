public class Task1 {
    public static void main(String[] args) {
//1)	Kiritilgan satrdagi katta harflarni kichik harfga, kichik harflarni katta harfga almashtiradigan dastur tuzilsin.
//      Kiruvchi ma'lumot: Phyton
//      Chiquvchi ma'lumot: pHYTON

        wordChange("Phyton");
    }

    private static void wordChange(String word) {

/*
        for (int i = 0; i < word.length(); i++) {
            if(Character.isUpperCase(word.charAt(i))) word.charAt(i);
            if(Character.isLowerCase(word.charAt(i))) lowerChars++;
            if(Character.isDigit(word.charAt(i)))     digitChars++;
        }
*/

    }
}
