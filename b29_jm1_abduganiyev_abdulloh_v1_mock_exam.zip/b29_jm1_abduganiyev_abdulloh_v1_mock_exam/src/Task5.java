public class Task5 {
    public static void main(String[] args) {
        //5)	Uzunligi 1 dan uzun bo’lgan satr berilgan.Satrdagi sonlar yig’indisini topadigan metod yozing.
        //
        //  M-n:
        //  ("abc123xyz") => 123
        //     ("aa11b33") => 44
        //  ("7 11") =>18

    }
}
