public class Task4 {
    public static void main(String[] args) {
            //4)	8x8 o'lchamli butun sonlardan iborat 2 o'lchovli massiv berilgan. Unda farzin i-qator j-ustunda turgan bo'lsa,
        //          u yurishi mumkin bo'lgan o'rinlarni 1 bilan, qolganlarini 0 bilan to'ldiring.
        //
        //Input: i=3, j=4
        //Output:
        //[0, 1, 0, 1, 0, 1, 0, 0]
        //[0, 0, 1, 1, 1, 0, 0, 0]
        //[1, 1, 1, 2, 1, 1, 1, 1]
        //[0, 0, 1, 1, 1, 0, 0, 0]
        //[0, 1, 0, 1, 0, 1, 0, 0]
        //[1, 0, 0, 1, 0, 0, 1, 0]
        //[0, 0, 0, 1, 0, 0, 0, 1]
        //[0, 0, 0, 1, 0, 0, 0, 0]

    }
}
